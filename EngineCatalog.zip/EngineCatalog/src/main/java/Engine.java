public class Engine {
    public String ImgPath;
    public String Name;     
    public int Year;
    public int HP;
    public int CC;
    public Engine(String imgPath, String name, int year, int hp, int cc){
        this.ImgPath = imgPath;
        this.Name = name;
        this.Year = year;
        this.HP = hp;
        this.CC = cc;
    }
}
